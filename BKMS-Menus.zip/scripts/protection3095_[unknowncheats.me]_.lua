require_game_build(3095)
local pro = menu.add_submenu("====== Protections ======")
local boolall = false 
local blockSocialClubSpamState = false
 
local function Text(text)
	pro:add_action(text, function() end)
end
 
Text("➫GTAv1.68 Protections")
Text("--")
 
local function Activity(bool)
	globals.set_bool(1683531+584, bool) 
end
 
local function Bounty(bool)
	globals.set_bool(1683531+65, bool) 
end
 
local function CeoKick(bool)
	globals.set_bool(1683531+556, bool) 
end
 
local function KickCrashes(bool)
	globals.set_bool(1683531+753, bool)
	globals.set_bool(1683531+453, bool)
	globals.set_bool(1683531+608, bool)
	globals.set_bool(1683531+623, bool)
	globals.set_bool(1683531+523, bool)
	globals.set_bool(1683531+600, bool)
	globals.set_bool(1683531+845, bool)
end
 
local function getKickCrashesState()
	return ( globals.get_bool(1683531+753) and
	globals.get_bool(1683531+453) and 
	globals.get_bool(1683531+608) and
	globals.get_bool(1683531+623) and
	globals.get_bool(1683531+523) and
	globals.get_bool(1683531+600) and
	globals.get_bool(1683531+845))
end
 
local function CeoBan(bool)
	globals.set_bool(1683531+578, bool) 
end
 
local function SoundSpam(bool)
	globals.set_bool(1683531+451, bool)
	globals.set_bool(1683531+850, bool)
	globals.set_bool(1683531, bool)
	--globals.set_bool(1670529, bool)
	globals.set_bool(1683531+630, bool)
	globals.set_bool(1683531+17, bool)
end
 
local function getSoundSpamState()
	return (globals.get_bool(1683531+451) and
	globals.get_bool(1683531+850) and
	globals.get_bool(1683531) and
	--globals.get_bool(1670529) and
	globals.get_bool(1683531+630) and
	globals.get_bool(1683531+17))
end
 
local function InfiniteLoad(bool)	
	globals.set_bool(1683531+579, bool) 
	globals.set_bool(1683531+648, bool)
end
 
local function getInfiniteLoadState()
	return (globals.get_bool(1683531+579) and
	globals.get_bool(1683531+648))
end
 
local function Collectibles(bool)
	globals.set_bool(1683531+815, bool) 
end
 
local function PassiveMode(bool)
	globals.set_bool(1683531+568, bool) 
end
 
local function TransactionError(bool) 
	globals.set_bool(1683531+369, bool) 
end
 
local function RemoveMoneyMessage(bool) 
	globals.set_bool(1683531+452, bool)
	globals.set_bool(1683531+22, bool)
	globals.set_bool(1683531+629, bool)
end
 
local function getRemoveMoneyMessageState()
	return (globals.get_bool(1683531+452) and
	globals.get_bool(1683531+22) and
	globals.get_bool(1683531+629))
end
 
local function ExtraTeleport(bool) 
	globals.set_bool(1683531+324, bool) 
	globals.set_bool(1683531+745, bool) 
    globals.set_bool(1683531+844, bool)
    globals.set_bool(1683531+845, bool)
    globals.set_bool(1683531+840, bool) 
end
 
local function getExtraTeleportState()
	return (globals.get_bool(1683531+324) and
	globals.get_bool(1683531+745) and globals.get_bool(1683531+844) and globals.get_bool(1683531+845) and globals.get_bool(1683531+840))
end
 
local function ClearWanted(bool) 
	globals.set_bool(1683531+510, bool)
end
 
local function OffTheRadar(bool) 
	globals.set_bool(1683531+512, bool) 
end
 
local function SendCutscene(bool) 
	globals.set_bool(1683531+805, bool)
end
 
local function Godmode(bool) 
	globals.set_bool(1683531+2, bool)
end
 
local function PersonalVehicleDestroy(bool) 
	globals.set_bool(1683531+73, bool)
	globals.set_bool(1683531+635, bool) 
end
 
local function getPersonalVehicleDestroyState()
	return (globals.get_bool(1683531+73) and
	globals.get_bool(1683531+635))
end
 
local function RemoteGlobalModification(bool)
	local setting = 0
	if bool then
		setting = 1
	end
	globals.set_int(1683531+793, setting)
	globals.set_int(1683531+470, setting)
end
 
local function getRemoteGlobalModificationState()
	return ((globals.get_int(1683531+793) == 1) and
	(globals.get_int(1683531+470) == 1))
end
 
local function BlockSocialclubSpam(bool)
	blockSocialClubSpamState = bool
end
 
local function getBlockSocialClubSpamState()
	return blockSocialClubSpamState
end
 
 
 
local function All(bool) 
	Activity(bool)
	Bounty(bool)
	CeoKick(bool)
	CeoBan(bool)
	SoundSpam(bool)
	InfiniteLoad(bool)
	PassiveMode(bool)
	TransactionError(bool)
	RemoveMoneyMessage(bool)
	ClearWanted(bool)
	OffTheRadar(bool)
	PersonalVehicleDestroy(bool)
	SendCutscene(bool)
	Godmode(bool)
	Collectibles(bool)
	ExtraTeleport(bool)
	KickCrashes(bool)
	RemoteGlobalModification(bool)
	BlockSocialclubSpam(bool)
end
 
pro:add_toggle("Activate All", function()
	return boolall
end, function()
	boolall = not boolall
	All(boolall)
end)
Text("--")
pro:add_toggle("Block Start Activity", function() --Credits to YimMenu
	return globals.get_bool(1683531+584)
end, function()
	Activity(not globals.get_bool(1683531+584))
end)
 
pro:add_toggle("Block Bounty", function()
	return globals.get_bool(1683531+65)
end, function()
	Bounty(not globals.get_bool(1683531+65))
end)
 
 
pro:add_toggle("Block Socialclub Spam", function()
	return getBlockSocialClubSpamState()
end, function(value)
	BlockSocialclubSpam(value)
end)
 
pro:add_toggle("Block Remote Global Modification", function()
	return getRemoteGlobalModificationState()
end, function()
	RemoteGlobalModification(not getRemoteGlobalModificationState())
end)
 
pro:add_toggle("Block Some Kicks&&Crashes", function()
	return getKickCrashesState()
end, function()
	KickCrashes(not getKickCrashesState())
end)
 
pro:add_toggle("Block Ceo Kick", function()
	return globals.get_bool(1683531+556)
end, function()
	CeoKick(not globals.get_bool(1683531+556))
end)
 
pro:add_toggle("Block Ceo Ban", function()
	return globals.get_bool(1683531+578) 
end, function()
	CeoBan(not globals.get_bool(1683531+578))
end)
 
pro:add_toggle("Block Sound Spam", function()
	return getSoundSpamState()
end, function()
	SoundSpam(not getSoundSpamState())
end)
 
pro:add_toggle("Block Infinite Loadingscreen", function()
	return getInfiniteLoadState()
end, function()
	InfiniteLoad(not getInfiniteLoadState())
end)
 
pro:add_toggle("Block Passive Mode", function()
	return globals.get_bool(1683531+568) 
end, function()
	PassiveMode(not globals.get_bool(1683531+568))
end)
 
pro:add_toggle("Block Transaction Error", function()
	return globals.get_bool(1683531+369)
end, function()
	TransactionError(not globals.get_bool(1683531+369))
end)
 
pro:add_toggle("Block Modded Notifys/SMS", function()
	return getRemoveMoneyMessageState()
end, function()
	RemoveMoneyMessage(not getRemoveMoneyMessageState())
end)
 
pro:add_toggle("Block Clear Wanted", function()
	return globals.get_bool(1683531+510)
end, function()
	ClearWanted(not globals.get_bool(1683531+510))
end)
 
pro:add_toggle("Block Off The Radar", function()
	return globals.get_bool(1683531+512)
end, function()
	OffTheRadar(not globals.get_bool(1683531+512))
end)
 
pro:add_toggle("Block Personal Vehicle Destroy", function()
	return getPersonalVehicleDestroyState()
end, function()
	PersonalVehicleDestroy(not getPersonalVehicleDestroyState())
end)
 
pro:add_toggle("Block Send to Cutscene", function()
	return globals.get_bool(1683531+805)
end, function()
	SendCutscene(not globals.get_bool(1683531+805))
end)
 
pro:add_toggle("Block Remove Godmode", function()
	return globals.get_bool(1683531+2)
end, function()
	Godmode(not globals.get_bool(1683531+2))
end)
 
pro:add_toggle("Block Give Collectibles", function()
	return globals.get_bool(1683531+815)
end, function()
	Collectibles(not globals.get_bool(1683531+815))
end)
 
pro:add_toggle("Block Cayo && Beach Teleport", function()
	return getExtraTeleportState()
end, function()
	ExtraTeleport(not getExtraTeleportState())
end)
 
 
function OnScriptsLoaded()
	local social_controller = script("social_controller")
	while true do
		if blockSocialClubSpamState then
			if social_controller:is_active() then
				social_controller:set_int(169, 0)
			end
		end
			
		-- Some sort of sleep is mandatory so other code can be executed (menu get/set and other triggers)
		sleep(1)
	end
end
 
menu.register_callback('OnScriptsLoaded', OnScriptsLoaded)
 
Text("--")
Text("By UC - Community")
Text("Original Code ➫ ΞΛZТΞΛ/SLON ")
Text("Improvements by ➫ quadplex")
Text("Addons by quadplex and Kiddion")
Text("--")