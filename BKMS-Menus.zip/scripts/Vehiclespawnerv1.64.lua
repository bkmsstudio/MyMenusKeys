--[[
██╗░░░██╗███████╗██╗░░██╗██╗░█████╗░██╗░░░░░███████╗  ░██████╗██████╗░░█████╗░░██╗░░░░░░░██╗███╗░░██╗███████╗██████╗░
██║░░░██║██╔════╝██║░░██║██║██╔══██╗██║░░░░░██╔════╝  ██╔════╝██╔══██╗██╔══██╗░██║░░██╗░░██║████╗░██║██╔════╝██╔══██╗
╚██╗░██╔╝█████╗░░███████║██║██║░░╚═╝██║░░░░░█████╗░░  ╚█████╗░██████╔╝███████║░╚██╗████╗██╔╝██╔██╗██║█████╗░░██████╔╝
░╚████╔╝░██╔══╝░░██╔══██║██║██║░░██╗██║░░░░░██╔══╝░░  ░╚═══██╗██╔═══╝░██╔══██║░░████╔═████║░██║╚████║██╔══╝░░██╔══██╗
░░╚██╔╝░░███████╗██║░░██║██║╚█████╔╝███████╗███████╗  ██████╔╝██║░░░░░██║░░██║░░╚██╔╝░╚██╔╝░██║░╚███║███████╗██║░░██║
░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═╝░╚════╝░╚══════╝╚══════╝  ╚═════╝░╚═╝░░░░░╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝░░╚══╝╚══════╝╚═╝░░╚═╝

░██████╗░█████╗░██████╗░██╗██████╗░████████╗  ███████╗░█████╗░██████╗░
██╔════╝██╔══██╗██╔══██╗██║██╔══██╗╚══██╔══╝  ██╔════╝██╔══██╗██╔══██╗
╚█████╗░██║░░╚═╝██████╔╝██║██████╔╝░░░██║░░░  █████╗░░██║░░██║██████╔╝
░╚═══██╗██║░░██╗██╔══██╗██║██╔═══╝░░░░██║░░░  ██╔══╝░░██║░░██║██╔══██╗
██████╔╝╚█████╔╝██║░░██║██║██║░░░░░░░░██║░░░  ██║░░░░░╚█████╔╝██║░░██║
╚═════╝░░╚════╝░╚═╝░░╚═╝╚═╝╚═╝░░░░░░░░╚═╝░░░  ╚═╝░░░░░░╚════╝░╚═╝░░╚═╝

██╗░░░██╗░░███╗░░░░░░█████╗░░░██╗██╗
██║░░░██║░████║░░░░░██╔═══╝░░██╔╝██║
╚██╗░██╔╝██╔██║░░░░░██████╗░██╔╝░██║
░╚████╔╝░╚═╝██║░░░░░██╔══██╗███████║
░░╚██╔╝░░███████╗██╗╚█████╔╝╚════██║
░░░╚═╝░░░╚══════╝╚═╝░╚════╝░░░░░░╚═╝]]
local cars_map = {}
cars_map[joaat("Cypher")] = "Cypher"
cars_map[joaat("ZR350")] = "ZR350"
cars_map[joaat("Jubilee")] = "Jubilee"
cars_map[joaat("Astron")] = "Astron"
cars_map[joaat("ZR380")] = "ZR380"
cars_map[joaat("Euros")] = "Euros"
cars_map[joaat("Zorrusso")] = "Zorrusso"
cars_map[joaat("Champion")] = "Champion"
cars_map[joaat("Vigilante")] = "Vigilante"
cars_map[joaat("Emerus")] = "Emerus"
cars_map[joaat("Ignus")] = "Ignus"
cars_map[joaat("Reaper")] = "Reaper"
cars_map[joaat("Tempesta")] = "Tempesta"
cars_map[joaat("Tezeract")] = "Tezeract"
cars_map[joaat("Nero")] = "Nero"
cars_map[joaat("T20")] = "T20"
cars_map[joaat("Zentorno")] = "Zentorno"
cars_map[joaat("Dubsta3")] = "Dubsta3"
cars_map[joaat("Verlierer2")] = "Verlierer2"
cars_map[joaat("Specter2")] = "Specter2"
cars_map[joaat("Ninef2")] = "Ninef2"
cars_map[joaat("Massacro2")] = "Massacro2"
cars_map[joaat("Miljet")] = "Miljet"
cars_map[joaat("Luxor2")] = "Luxor2"
cars_map[joaat("Tampa3")] = "Tampa3"
cars_map[joaat("Gauntlet2")] = "Gauntlet2"
cars_map[joaat("Dominator2")] = "Dominator2"
cars_map[joaat("Hakuchou")] = "Hakuchou"
cars_map[joaat("Hakuchou2")] = "Hakuchou2"
cars_map[joaat("Rhino")] = "Rhino"
cars_map[joaat("Police2")] = "Police2"
cars_map[joaat("FBI2")] = "FBI2"
cars_map[joaat("Banshee2")] = "Banshee2"
cars_map[joaat("Lazer")] = "Lazer"
cars_map[joaat("Sanctus")] = "Sanctus"
cars_map[joaat("Shotaro")] = "Shotaro"
cars_map[joaat("Jester2")] = "Jester2"
cars_map[joaat("BATI2")] = "Bati 801RR"
cars_map[joaat("BIFTA")] = "Bifta"
cars_map[joaat("ADDER")] = "adder"
cars_map[joaat("SCRAMJET")] = "ScramJet"
cars_map[joaat("DINGHY2")] = "cdinghy"
cars_map[joaat("ANNIHILATOR")] = "AnniHilator"
cars_map[joaat("AVENGER2")] = "Avenger2"
cars_map[joaat("BUZZARD2")] = "Buzzard2"
cars_map[joaat("CHEETAH2")] = "Cheetah2"
cars_map[joaat("COACH")] = "Coach"
cars_map[joaat("COMET5")] = "Comet5"
cars_map[joaat("DELUXO")] = "Deluxo"
cars_map[joaat("DINGHY4")] = "Dinghy4"
cars_map[joaat("ELEGY2")] = "Elegy2"
cars_map[joaat("VELUM2")] = "Velum"
cars_map[joaat("LAZER")] = "Lazer"
cars_map[joaat("LIMO2")] = "Limo2"
cars_map[joaat("MAVERICK")] = "Maverick"
cars_map[joaat("MONSTER")] = "Monster"
cars_map[joaat("SULTANRS")] = "Sultanrs"
cars_map[joaat("INSURGENT3")] = "Insurgetnt3"
cars_map[joaat("OPPRESSOR2")] = "Oppressor2"
cars_map[joaat("JETMAX")] = "Jetmax"
cars_map[joaat("HYDRA")] = "Hydra"
local car_hash = joaat("BATI2")
 
menu.add_array_item("Spawn Vehicle", cars_map, function()
	return car_hash
end, function(value)
	car_hash = value
	local pos = localplayer:get_position()
	globals.set_int(2639783 + 46, value)
	globals.set_float(2639783 + 42, pos.x)
	globals.set_float(2639783 + 43, pos.y)
	globals.set_float(2639783 + 44, pos.z)
	globals.set_boolean(2639783 + 41, true)
end)
--[[
░█████╗░██████╗░███████╗██████╗░██╗████████╗░██████╗  ████████╗░█████╗░
██╔══██╗██╔══██╗██╔════╝██╔══██╗██║╚══██╔══╝██╔════╝  ╚══██╔══╝██╔══██╗
██║░░╚═╝██████╔╝█████╗░░██║░░██║██║░░░██║░░░╚█████╗░  ░░░██║░░░██║░░██║
██║░░██╗██╔══██╗██╔══╝░░██║░░██║██║░░░██║░░░░╚═══██╗  ░░░██║░░░██║░░██║
╚█████╔╝██║░░██║███████╗██████╔╝██║░░░██║░░░██████╔╝  ░░░██║░░░╚█████╔╝
░╚════╝░╚═╝░░╚═╝╚══════╝╚═════╝░╚═╝░░░╚═╝░░░╚═════╝░  ░░░╚═╝░░░░╚════╝░

░░░██╗░██╗░██╗░░██╗██╗██████╗░██████╗░██╗░█████╗░███╗░░██╗
██████████╗██║░██╔╝██║██╔══██╗██╔══██╗██║██╔══██╗████╗░██║
╚═██╔═██╔═╝█████═╝░██║██║░░██║██║░░██║██║██║░░██║██╔██╗██║
██████████╗██╔═██╗░██║██║░░██║██║░░██║██║██║░░██║██║╚████║
╚██╔═██╔══╝██║░╚██╗██║██████╔╝██████╔╝██║╚█████╔╝██║░╚███║
░╚═╝░╚═╝░░░╚═╝░░╚═╝╚═╝╚═════╝░╚═════╝░╚═╝░╚════╝░╚═╝░░╚══╝

░██╗░░░░░░░██╗░██╗░░░░░░░██╗░██╗░░░░░░░██╗░░░████████╗██╗░░██╗██╗███████╗██╗░██████╗░██████╗░█████╗░███╗░░░███╗░░░██╗███╗░░██╗
░██║░░██╗░░██║░██║░░██╗░░██║░██║░░██╗░░██║░░░╚══██╔══╝██║░░██║██║╚════██║██║██╔════╝██╔════╝██╔══██╗████╗░████║░░░██║████╗░██║
░╚██╗████╗██╔╝░╚██╗████╗██╔╝░╚██╗████╗██╔╝░░░░░░██║░░░███████║██║░░███╔═╝██║╚█████╗░╚█████╗░███████║██╔████╔██║░░░██║██╔██╗██║
░░████╔═████║░░░████╔═████║░░░████╔═████║░░░░░░░██║░░░██╔══██║██║██╔══╝░░██║░╚═══██╗░╚═══██╗██╔══██║██║╚██╔╝██║░░░██║██║╚████║
░░╚██╔╝░╚██╔╝░░░╚██╔╝░╚██╔╝░░░╚██╔╝░╚██╔╝░██╗░░░██║░░░██║░░██║██║███████╗██║██████╔╝██████╔╝██║░░██║██║░╚═╝░██║██╗██║██║░╚███║
░░░╚═╝░░░╚═╝░░░░░╚═╝░░░╚═╝░░░░░╚═╝░░░╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝╚═╝╚══════╝╚═╝╚═════╝░╚═════╝░╚═╝░░╚═╝╚═╝░░░░░╚═╝╚═╝╚═╝╚═╝░░╚══╝]]