local demo_menu = menu.add_submenu("Doomsday Skip + Cut Editor")
local function Text(text)
	demo_menu:add_action(text, function() end)
end
Text(" _____________Doomsday Setup______________")
 
demo_menu:add_int_range("Data/Bogdan/Doomsday)", 1, 1, 3, function() return 1 end, function(ActNum)
	if ActNum == 1 then
		DProg = 503
		DStat = 229383
	elseif ActNum == 2 then
		DProg = 240
		DStat = 229378
	else
		DProg = 16368
		DStat = 229380
	end
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		mpx = "MP0_"
	else
		mpx = "MP1_"
	end
		stats.set_int(mpx .. "GANGOPS_FLOW_MISSION_PROG", DProg)
		stats.set_int(mpx .. "GANGOPS_HEIST_STATUS", DStat)
		stats.set_int(mpx .. "GANGOPS_FLOW_NOTIFICATIONS", 1557)
end)
 


local function Text(text)
	menu.add_action(text, function() end)
end
 demo_menu:add_int_range("Doomsday Player1", 10.0, 15, 300, function() 
	return globals.get_int(1959865 + 812 + 50 + 1)
end, function(value)
	globals.set_int(1959865 + 812 + 50 + 1, value)
end)
 
 demo_menu:add_int_range("Doomsday Player2", 10.0, 15, 300, function() 
	return globals.get_int(1959865 + 812 + 50 + 2)
end, function(value)
	globals.set_int(1959865 + 812 + 50 + 2, value)
end)
 
 demo_menu:add_int_range("Doomsday Player3", 10.0, 15, 300,function() 
	return globals.get_int(1959865 + 812 + 50 + 1 + 1 + 1)
end, function(value)
	globals.set_int(1959865 + 812 + 50 + 1 + 1 + 1, value)
end)
 
 demo_menu:add_int_range("Doomsday Player4", 10.0, 15, 300, function() 
	return globals.get_int(1959865 + 812 + 50 + 1 + 1 + 1 + 1)
end, function(value)
	globals.set_int(1959865 + 812 + 50 + 1 + 1 + 1 + 1, value)
end)

require_game_build(3095)
 demo_menu:add_action("Skip Doomsday Beam-Hack (ACT-III)", function()
	local heist_script = script("fm_mission_controller")
	if heist_script and heist_script:is_active() then
		if heist_script:get_int(1269 + 135) > 0.0 or heist_script < 99.9 then
			heist_script:set_int(1269 + 135, 3)
		end
	end
end)